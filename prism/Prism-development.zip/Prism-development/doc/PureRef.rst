PureRef
===================================

.. toctree::
   :glob:
   :maxdepth: 2

   autodoc/plugins/PureRef/*
