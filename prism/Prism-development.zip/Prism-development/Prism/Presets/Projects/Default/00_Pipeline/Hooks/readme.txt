The Hooks folder contains python scripts, which gets executed during the execution of State Manager states.
You can add your own python code to these scripts, to modify your scene or call any custom features, which you want to add to your workflow.
You can also create new hooks, which are named like Prism callbacks. They will get executed when the callback is triggered in Prism.