# This script will be executed after the execution of an render state in the Prism State Manager.
# You can use this file to define project specific actions, like modifying the created images.

# Example:
# print "Prism has rendered images."

# If the main function exists in this script, it will be called.
# The "kwargs" argument is a dictionary with usefull information about Prism and the current export.


# def main(*args, **kwargs):
#     print(args)
#     print(kwargs)
#     print(kwargs["core"].projectName)
#     print(kwargs["state"].l_taskName.text())
#     print(kwargs["scenefile"])
#     print(kwargs["settings"])
