# This script will be executed after the import state in the Prism State Manager has imported objects.
# You can use this file to define project specific actions, like manipulating the imported objects.

# Example:
# print "Prism has imported objects."

# If the main function exists in this script, it will be called.
# The "kwargs" argument is a dictionary with usefull information about Prism and the current export.


# def main(*args, **kwargs):
#     print(args)
#     print(kwargs)
#     print(kwargs["core"].projectName)
#     print(kwargs["state"])
#     print(kwargs["scenefile"])
#     print(kwargs["importfile"])
#     print(kwargs["importedObjects"])
