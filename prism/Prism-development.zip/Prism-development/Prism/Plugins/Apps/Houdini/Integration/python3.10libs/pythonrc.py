# >>>PrismStart
try:
    import PrismInit

    PrismInit.createPrismCore()
except Exception as e:
    print(str(e))
# <<<PrismEnd
